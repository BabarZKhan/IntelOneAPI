rm -f compare_results.txt
rm -f *.d
rm -f *.emu
rm -f *.o
rm -rf *.prj
rm -f *.a
rm -f *.out
rm -f *.opt
