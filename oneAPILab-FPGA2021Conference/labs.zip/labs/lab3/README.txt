For this lab, you will be working from a PDF file to prevent you from having to switch tabs an extraordinary amount in Jupyter Lab.

Open the file Hough_transform_lab.pdf and follow the instructions found there.